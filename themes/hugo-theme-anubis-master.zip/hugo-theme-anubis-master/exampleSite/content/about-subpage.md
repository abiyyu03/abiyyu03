---
title: "About subpage"
description: "About subpage"
date: "2019-02-28"
author: "Hugo Authors"
slug: /about/subpage
menu:
  about:
    identifier: about-subpage-s
    parent: about
    name: About Subpage
    title: About Subpage
    url: /about/subpage/
    weight: 1
  subpage:
    identifier: about-subpage2-s
    parent: about
    name: Second About subpage
    title: Second About subpage
    url: /about/subpage2/
    weight: 10
---

About subpage
