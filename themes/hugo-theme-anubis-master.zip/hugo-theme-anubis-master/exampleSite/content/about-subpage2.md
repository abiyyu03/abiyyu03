---
title: "Second About subpage"
description: "Second About subpage"
date: "2019-02-28"
author: "Hugo Authors"
slug: /about/subpage2
menu:
  about:
    identifier: about-subpage-s2
    parent: about
    name: About Subpage
    title: About Subpage
    url: /about/subpage/
    weight: 1
  subpage:
    identifier: about-subpage2-s2
    parent: about
    name: Second About subpage
    title: Second About subpage
    url: /about/subpage2/
    weight: 10
---

Second About subpage
