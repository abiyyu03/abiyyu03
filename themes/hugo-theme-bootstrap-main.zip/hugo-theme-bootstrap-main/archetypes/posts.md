---
categories: [""]
date: {{ .Date }}
draft: true
title: "{{ replace .Name "-" " " | title }}"
url: ""
---

**Replace with Summary to Display**

<!--more-->

**Replace with Rest of Content**